﻿using Microsoft.CSharp.RuntimeBinder;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.CompilerServices;
using System.Web;
using System.Configuration;
using System.Web.Mvc;
using TransCanada.Models;
using TransCanadaDemo.Controllers;

namespace TransCanada.Controllers
{
    [Authorize]
    public class LabController : Controller
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TransCanadaConnection"].ConnectionString);

        public ActionResult LabList()
        {
            List<Lab_loc> labLocList = new List<Lab_loc>();
            try
            {
                SqlCommand selectCommand = new SqlCommand("select Location_Name from tbl_Clinic_Details where isdeleted=0  group by Location_Name ", this.conn);
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommand);
                DataTable dataTable = new DataTable();
                sqlDataAdapter.Fill(dataTable);
                if (dataTable.Rows.Count > 0)
                {
                    for (int index = 0; index < dataTable.Rows.Count; ++index)
                        labLocList.Add(new Lab_loc()
                        {
                            Id = index + 1,
                            Lab_Name = string.IsNullOrEmpty(dataTable.Rows[index]["Location_Name"].ToString()) ? string.Empty : dataTable.Rows[index]["Location_Name"].ToString()
                        });
                }
            }
            catch (Exception ex)
            {
            }
            return (ActionResult)this.View((object)labLocList);
        }

        public ActionResult Locations(string id)
        {
            List<lab_location> labLocationList = new List<lab_location>();
            if (id != null)
            {
                // ISSUE: reference to a compiler-generated field
                ViewBag.LabName = id.Trim();
                SqlCommand selectCommand = new SqlCommand("Get_Location_for_lab", this.conn);
                selectCommand.CommandType = CommandType.StoredProcedure;
                selectCommand.Parameters.AddWithValue("@Location_Name", (object)id);
                DataTable dataTable = new DataTable();
                new SqlDataAdapter(selectCommand).Fill(dataTable);
                if (dataTable.Rows.Count > 0)
                {
                    for (int index = 0; index < dataTable.Rows.Count; ++index)
                        labLocationList.Add(new lab_location()
                        {
                            Id1 = string.IsNullOrEmpty(dataTable.Rows[index]["Location_Id"].ToString()) ? string.Empty : dataTable.Rows[index]["Location_Id"].ToString(),
                            Address_1 = string.IsNullOrEmpty(dataTable.Rows[index]["Address_1"].ToString()) ? string.Empty : dataTable.Rows[index]["Address_1"].ToString(),
                            Address_2 = string.IsNullOrEmpty(dataTable.Rows[index]["Address_2"].ToString()) ? string.Empty : dataTable.Rows[index]["Address_2"].ToString(),
                            City = string.IsNullOrEmpty(dataTable.Rows[index]["City"].ToString()) ? string.Empty : dataTable.Rows[index]["City"].ToString(),
                            State = string.IsNullOrEmpty(dataTable.Rows[index]["State"].ToString()) ? string.Empty : dataTable.Rows[index]["State"].ToString(),
                            Zip = string.IsNullOrEmpty(dataTable.Rows[index]["Zip"].ToString()) ? string.Empty : dataTable.Rows[index]["Zip"].ToString(),
                            Country = string.IsNullOrEmpty(dataTable.Rows[index]["Country"].ToString()) ? string.Empty : dataTable.Rows[index]["Country"].ToString()
                        });
                }
            }
            return (ActionResult)this.View((object)labLocationList);
        }

        public ActionResult AddLab(string id)
        {
            if (id == null)
            {
                lab_location lab_Location = new lab_location();
                ViewBag.Status = string.Empty;
                lab_Location.hide_id = "2";
                lab_Location.Id1 = string.Empty;
                ClientController clientController = new ClientController();
                lab_Location.Cities = clientController.GetAllCities(string.Empty);
                return View(lab_Location);
            }
            else
            {

                lab_location lab_Location = new lab_location();
                ViewBag.Status = id;
                lab_Location.Lab_Name = id;
                lab_Location.hide_id = "3";
                lab_Location.Id1 = string.Empty;
                ClientController clientController = new ClientController();
                lab_Location.Cities = clientController.GetAllCities(string.Empty);
                return View(lab_Location);
            }
        }

        [HttpPost]
        public ActionResult AddLab(lab_location lab_Location)
        {
            if (ModelState.IsValid)
            {
                SqlCommand sqlCommand = new SqlCommand("Proc_Create_Lab", this.conn);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@Location_Name", (object)lab_Location.Lab_Name);
                sqlCommand.Parameters.AddWithValue("@Address_1", (object)lab_Location.Address_1);
                sqlCommand.Parameters.AddWithValue("@Location_Id", (object)lab_Location.Id1);
                if (lab_Location.Address_2 == null)
                {
                    sqlCommand.Parameters.AddWithValue("@Address_2", string.Empty);
                }
                else
                {
                    sqlCommand.Parameters.AddWithValue("@Address_2", (object)lab_Location.Address_2);
                }
                sqlCommand.Parameters.AddWithValue("@City", (object)lab_Location.City);
                sqlCommand.Parameters.AddWithValue("@State", (object)lab_Location.State);
                sqlCommand.Parameters.AddWithValue("@Zip", (object)lab_Location.Zip);
                sqlCommand.Parameters.AddWithValue("@Country", (object)lab_Location.Country);
                //sqlCommand.Parameters.AddWithValue("@companyid", Session["Account_id"]);
                conn.Open();
                sqlCommand.ExecuteNonQuery();
                conn.Close();
                if (lab_Location.hide_id == "2")
                    return (ActionResult)this.RedirectToAction("LabList");
                return (ActionResult)this.RedirectToAction("Locations", (object)new
                {
                    id = lab_Location.Lab_Name
                });
            }
            else
            {
                if (lab_Location.hide_id == "2")
                {
                    ViewBag.Status = string.Empty;

                }
                else
                {
                    ViewBag.Status = lab_Location.Lab_Name;

                }
                ClientController clientController = new ClientController();
                if (lab_Location.State == null)
                    lab_Location.Cities = clientController.GetAllCities(string.Empty);
                else
                    lab_Location.Cities = clientController.GetAllCities(lab_Location.State);
                return (ActionResult)this.View(lab_Location);
            }

        }

        public ActionResult Delete(string id)
        {
            if (id != null)
            {
                SqlCommand sqlCommand = new SqlCommand("update tbl_Clinic_Details set isdeleted=1 where Location_Name=@Location_Name", this.conn);
                sqlCommand.Parameters.AddWithValue("@Location_Name", (object)id);
                conn.Open();
                sqlCommand.ExecuteNonQuery();
                conn.Close();
            }
            return (ActionResult)this.RedirectToAction("LabList");
        }

        public ActionResult deletelabloc(string id)
        {
            SqlCommand sqlCommand1 = new SqlCommand("select Location_name from tbl_clinic_details where Location_id=@Location_id", this.conn);
            sqlCommand1.Parameters.AddWithValue("@Location_id", (object)id);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCommand1);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            SqlCommand sqlCommand = new SqlCommand("proc_delete_lab_loc", this.conn);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.Parameters.AddWithValue("@id", (object)id);
            conn.Open();
            sqlCommand.ExecuteNonQuery();
            conn.Close();
            string id1 = dataTable.Rows[0][0].ToString();
            return RedirectToAction("Locations",new {id=id1 });
        }

        public ActionResult UpdateLabLocation(string id)
        {
            lab_location labLocation = new lab_location();
            if (!string.IsNullOrEmpty(id))
            {
                SqlCommand selectCommand = new SqlCommand("Get_Location_for_lab_by_id", this.conn);
                selectCommand.CommandType = CommandType.StoredProcedure;
                selectCommand.Parameters.AddWithValue("@Location_Id", (object)id);
                DataTable dataTable = new DataTable();
                new SqlDataAdapter(selectCommand).Fill(dataTable);
                labLocation.Id1 = id.ToString();
                labLocation.hide_id = id;
                if (dataTable.Rows.Count > 0)
                {
                    int index = 0;
                    labLocation.Lab_Name = string.IsNullOrEmpty(dataTable.Rows[index]["Location_Name"].ToString()) ? string.Empty : dataTable.Rows[index]["Location_Name"].ToString();
                    labLocation.Address_1 = string.IsNullOrEmpty(dataTable.Rows[index]["Address_1"].ToString()) ? string.Empty : dataTable.Rows[index]["Address_1"].ToString();
                    labLocation.Address_2 = string.IsNullOrEmpty(dataTable.Rows[index]["Address_2"].ToString()) ? string.Empty : dataTable.Rows[index]["Address_2"].ToString();
                    labLocation.City = string.IsNullOrEmpty(dataTable.Rows[index]["City"].ToString()) ? string.Empty : dataTable.Rows[index]["City"].ToString();
                    if (!string.IsNullOrEmpty(dataTable.Rows[index]["State"].ToString()))
                    {
                        labLocation.State = dataTable.Rows[index]["State"].ToString();
                        ClientController clientController = new ClientController();
                        labLocation.Cities = clientController.GetAllCities(dataTable.Rows[0]["State"].ToString());
                    }
                    else
                    {
                        labLocation.State = string.Empty;
                        ClientController clientController = new ClientController();
                        labLocation.Cities = clientController.GetAllCities(string.Empty);
                    }
                    labLocation.Zip = string.IsNullOrEmpty(dataTable.Rows[index]["Zip"].ToString()) ? string.Empty : dataTable.Rows[index]["Zip"].ToString();
                    labLocation.Country = string.IsNullOrEmpty(dataTable.Rows[index]["Country"].ToString()) ? string.Empty : dataTable.Rows[index]["Country"].ToString();
                }
            }
            return (ActionResult)this.View((object)labLocation);
        }

        [HttpPost]
        public ActionResult UpdateLabLocation(lab_location lab_Location)
        {
            if (ModelState.IsValid)
            {
                SqlCommand sqlCommand = new SqlCommand("Proc_Update_Lab", this.conn);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@Location_Id", (object)lab_Location.Id1);
                sqlCommand.Parameters.AddWithValue("@Address_1", (object)lab_Location.Address_1);
                if (!string.IsNullOrEmpty(lab_Location.Address_2))
                    sqlCommand.Parameters.AddWithValue("@Address_2", (object)lab_Location.Address_2);
                else
                    sqlCommand.Parameters.AddWithValue("@Address_2", string.Empty);
                sqlCommand.Parameters.AddWithValue("@City", (object)lab_Location.City);
                sqlCommand.Parameters.AddWithValue("@State", (object)lab_Location.State);
                sqlCommand.Parameters.AddWithValue("@Zip", (object)lab_Location.Zip);
                if (!string.IsNullOrEmpty(lab_Location.Address_2))
                    sqlCommand.Parameters.AddWithValue("@Country", (object)lab_Location.Country);
                else
                    sqlCommand.Parameters.AddWithValue("@Country", string.Empty);
                conn.Open();
                sqlCommand.ExecuteNonQuery();
                conn.Close();
                return (ActionResult)this.RedirectToAction("Locations", (object)new
                {
                    id = lab_Location.Lab_Name+"/"
                });
            }
            ClientController clientController = new ClientController();
            if(string.IsNullOrEmpty(lab_Location.State))
            lab_Location.Cities = clientController.GetAllCities(string.Empty);
            else
                lab_Location.Cities = clientController.GetAllCities(lab_Location.State);
            return (ActionResult)this.View(lab_Location);
        }

        public ActionResult NewLab()
        {
            return View();
        }

        [HttpPost]
        public ActionResult NewLab(lab_loc_name lab_Loc_Name)
        {
            if (!ModelState.IsValid)
                return View(lab_Loc_Name);
            SqlCommand sqlCommand = new SqlCommand("proc_new_lab", this.conn);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.Parameters.AddWithValue("@Locationname", (object)lab_Loc_Name.Lab_Name);
            sqlCommand.Parameters.AddWithValue("@location_id", lab_Loc_Name.Lab_Name + "Def_loc");
            conn.Open();
            sqlCommand.ExecuteNonQuery();
            conn.Close();
            return RedirectToAction("Lablist");
        }

        public ActionResult ContactDetails(int id)
        {
            Lab_contact labContact = new Lab_contact();
            if (id != 0)
            {
                SqlCommand selectCommand = new SqlCommand("proc_edit_Lab_contact", this.conn);
                selectCommand.CommandType = CommandType.StoredProcedure;
                selectCommand.Parameters.AddWithValue("@lab_contact_id", (object)id);
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommand);
                DataTable dataTable = new DataTable();
                sqlDataAdapter.Fill(dataTable);
                labContact.contact_id = id;
                if (dataTable.Rows.Count > 0)
                {
                    labContact.email = string.IsNullOrEmpty(dataTable.Rows[0]["Email"].ToString()) ? string.Empty : dataTable.Rows[0]["Email"].ToString();
                    labContact.firstname = string.IsNullOrEmpty(dataTable.Rows[0]["firstname"].ToString()) ? string.Empty : dataTable.Rows[0]["firstname"].ToString();
                    labContact.Lastname = string.IsNullOrEmpty(dataTable.Rows[0]["lastname"].ToString()) ? string.Empty : dataTable.Rows[0]["lastname"].ToString();
                    labContact.officephone = string.IsNullOrEmpty(dataTable.Rows[0]["officephone"].ToString()) ? string.Empty : dataTable.Rows[0]["officephone"].ToString();
                    labContact.cell = string.IsNullOrEmpty(dataTable.Rows[0]["cell"].ToString()) ? string.Empty : dataTable.Rows[0]["cell"].ToString();
                    if (!string.IsNullOrEmpty(dataTable.Rows[0]["lab_Location_Id"].ToString()))
                        labContact.location_id = dataTable.Rows[0]["lab_Location_Id"].ToString();
                }
            }
            return (ActionResult)this.View((object)labContact);
        }

        [HttpPost]
        public ActionResult ContactDetails(Lab_contact _Contact)
        {
            if (!ModelState.IsValid)
                return (ActionResult)this.View();
            SqlCommand sqlCommand = new SqlCommand("proc_Update_Lab_contact", this.conn);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.Parameters.AddWithValue("@lab_contact_id", (object)_Contact.contact_id);
            sqlCommand.Parameters.AddWithValue("@firstname", (object)_Contact.firstname);
            sqlCommand.Parameters.AddWithValue("@lastname", (object)_Contact.Lastname);
            if (_Contact.officephone == null)
                sqlCommand.Parameters.AddWithValue("@officephone", (object)string.Empty);
            else
                sqlCommand.Parameters.AddWithValue("@officephone", (object)_Contact.officephone);
            if (_Contact.cell != null)
                sqlCommand.Parameters.AddWithValue("@cell", (object)_Contact.cell);
            else
                sqlCommand.Parameters.AddWithValue("@cell", string.Empty);
            sqlCommand.Parameters.AddWithValue("@email", (object)_Contact.email);
            conn.Open();
            sqlCommand.ExecuteNonQuery();
            conn.Close();
            return (ActionResult)this.RedirectToAction("ContactsList", (object)new
            {
                id = _Contact.location_id
            });
        }

        public ActionResult LabServices(string id)
        {
            List<Services> servicesList = new List<Services>();
            ViewBag.LabName = id.Trim();
            id = id.Trim();
            if (string.IsNullOrEmpty(id))
                return (ActionResult)this.Redirect(Request.UrlReferrer.AbsolutePath);
            SqlCommand sqlCommand = new SqlCommand("select id,service_grp_name from lab_service_grp where LabName=@LabName", this.conn);
            sqlCommand.Parameters.AddWithValue("@LabName", (object)id);
            conn.Open();
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            if (sqlDataReader.HasRows)
            {
                while (sqlDataReader.Read())
                    servicesList.Add(new Services()
                    {
                        Service_id = Convert.ToInt32(sqlDataReader[nameof(id)]),
                        Service_Name = Convert.ToString(sqlDataReader["service_grp_name"])
                    });
            }
            return (ActionResult)this.View((object)servicesList);
        }

        public ActionResult CreateServiceGroup(string id)
        {
            return (ActionResult)this.View((object)new Services()
            {
                Labid = id.ToString()
            });
        }

        [HttpPost]
        public ActionResult CreateServiceGroup(Services services)
        {
            if (!ModelState.IsValid)
                return (ActionResult)this.View((object)services);
            SqlCommand sqlCommand = new SqlCommand("insert into lab_service_grp (service_grp_name,LabName) values (@service_grp_name,@LabName)", this.conn);
            sqlCommand.Parameters.AddWithValue("@LabName", (object)services.Labid);
            sqlCommand.Parameters.AddWithValue("@service_grp_name", (object)services.Service_Name);
            conn.Open();
            sqlCommand.ExecuteNonQuery();
            conn.Close();
            return (ActionResult)this.RedirectToAction("LabServices", (object)new
            {
                id = services.Labid
            });
        }

        public ActionResult UpdateServiceGroup(int id)
        {
            List<SubServices> subServicesList = new List<SubServices>();
            Services services = new Services();
            services.Service_id = id;
            SqlCommand selectCommand = new SqlCommand("select service_grp_name,Labname from lab_service_grp where id=@id", this.conn);
            selectCommand.Parameters.AddWithValue("@id", (object)id);
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommand);
            DataTable dataTable = new DataTable();
            sqlDataAdapter.Fill(dataTable);
            if (dataTable.Rows.Count > 0)
            {
                services.Service_Name = string.IsNullOrEmpty(dataTable.Rows[0]["service_grp_name"].ToString()) ? string.Empty : dataTable.Rows[0]["service_grp_name"].ToString();
                services.Labid = string.IsNullOrEmpty(dataTable.Rows[0]["Labname"].ToString()) ? string.Empty : dataTable.Rows[0]["Labname"].ToString();
            }
            SqlCommand sqlCommand = new SqlCommand("select * from tbl_lab_sub_service where lab_service_grp_id=@id", this.conn);
            sqlCommand.Parameters.AddWithValue("@id", (object)id);
            conn.Open();
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            if (sqlDataReader.HasRows)
            {
                while (sqlDataReader.Read())
                    subServicesList.Add(new SubServices()
                    {
                        lab_services_description = sqlDataReader["lab_services_description"].ToString(),
                        lab_service_id = Convert.ToInt32(sqlDataReader[nameof(id)].ToString()),
                        lab_services_ext_description = sqlDataReader["lab_services_ext_description"].ToString(),
                        service_charges = Convert.ToDecimal(sqlDataReader["service_charges"].ToString()),
                        client_billing_charges = Convert.ToDecimal(sqlDataReader["client_billing_charges"].ToString())
                    });
                sqlDataReader.Close();
                conn.Close();
            }
            else
            {
                sqlDataReader.Close();
                conn.Close();
            }
            ViewData["Data"] = subServicesList;
            return (ActionResult)this.View((object)services);
        }

        [HttpPost]
        public ActionResult UpdateServiceGroup(Services services)
        {
            if (!ModelState.IsValid)
            {
                List<SubServices> subServicesList = new List<SubServices>();
                
                SqlCommand sqlCommand = new SqlCommand("select * from tbl_lab_sub_service where lab_service_grp_id=@id", this.conn);
                sqlCommand.Parameters.AddWithValue("@id", (object)services.Service_id);
                conn.Open();
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                if (sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                        subServicesList.Add(new SubServices()
                        {
                            lab_services_description = sqlDataReader["lab_services_description"].ToString(),
                            lab_service_id = Convert.ToInt32(sqlDataReader["id"].ToString()),
                            lab_services_ext_description = sqlDataReader["lab_services_ext_description"].ToString(),
                            service_charges = Convert.ToDecimal(sqlDataReader["service_charges"].ToString()),
                            client_billing_charges = Convert.ToDecimal(sqlDataReader["client_billing_charges"].ToString())
                        });
                    sqlDataReader.Close();
                    conn.Close();
                }
                else
                {
                    sqlDataReader.Close();
                    conn.Close();
                }
                ViewData["Data"] = subServicesList;
                return (ActionResult)this.View((object)services);
            }
            else
            {
                SqlCommand sqlCommand = new SqlCommand("update lab_service_grp set service_grp_name=@service_grp_name where id=@id", this.conn);
                sqlCommand.Parameters.AddWithValue("@id", (object)services.Service_id);
                sqlCommand.Parameters.AddWithValue("@service_grp_name", (object)services.Service_Name);
                conn.Open();
                sqlCommand.ExecuteNonQuery();
                conn.Close();
                return (ActionResult)this.RedirectToAction("LabServices", (object)new
                {
                    id = services.Labid
                });
            }
        }

        public ActionResult DeleteServiceGroup(int id)
        {
            SqlCommand sqlCommand = new SqlCommand("delete from lab_service_grp where id=@service_grp_id", this.conn);
            sqlCommand.Parameters.AddWithValue("@service_grp_id", (object)id);
            conn.Open();
            sqlCommand.ExecuteNonQuery();
            conn.Close();
            return (ActionResult)this.Redirect(Request.UrlReferrer.AbsolutePath);
        }

        public ActionResult CreateSubService(int id)
        {
            return (ActionResult)this.View((object)new SubServices()
            {
                lab_group_id = id
            });
        }

        [HttpPost]
        public ActionResult CreateSubService(SubServices subServices)
        {
            if (!ModelState.IsValid)
                return (ActionResult)this.View((object)subServices);
            SqlCommand sqlCommand = new SqlCommand("tbl_lab_sub_service_gener", this.conn);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.Parameters.AddWithValue("@lab_service_grp_id", (object)subServices.lab_group_id);
            sqlCommand.Parameters.AddWithValue("@lab_services_description", (object)subServices.lab_services_description);
            sqlCommand.Parameters.AddWithValue("@lab_services_ext_description", (object)subServices.lab_services_ext_description);
            sqlCommand.Parameters.AddWithValue("@service_charges", (object)subServices.service_charges);
            sqlCommand.Parameters.AddWithValue("@client_billing_charges", (object)subServices.client_billing_charges);
            conn.Open();
            sqlCommand.ExecuteNonQuery();
            conn.Close();
            return (ActionResult)this.RedirectToAction("UpdateServiceGroup", (object)new
            {
                id = subServices.lab_group_id
            });
        }

        public ActionResult UpdateSubService(int id)
        {
            SubServices subServices = new SubServices();
            subServices.lab_service_id = id;
            SqlCommand sqlCommand = new SqlCommand("tbl_lab_sub_service_get", this.conn);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.Parameters.AddWithValue("@id", (object)id);
            conn.Open();
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            if (sqlDataReader.HasRows)
            {
                while (sqlDataReader.Read())
                {
                    subServices.lab_services_description = sqlDataReader["lab_services_description"].ToString();
                    subServices.lab_services_ext_description = sqlDataReader["lab_services_ext_description"].ToString();
                    subServices.client_billing_charges = Convert.ToDecimal(sqlDataReader["client_billing_charges"].ToString());
                    subServices.service_charges = Convert.ToDecimal(sqlDataReader["service_charges"].ToString());
                    subServices.lab_group_id = Convert.ToInt32(sqlDataReader["lab_service_grp_id"].ToString());
                }
                sqlDataReader.Close();
                conn.Close();
            }
            else
            {
                sqlDataReader.Close();
                conn.Close();
            }
            return (ActionResult)this.View((object)subServices);
        }

        [HttpPost]
        public ActionResult UpdateSubService(SubServices subServices)
        {
            if (!ModelState.IsValid)
                return (ActionResult)this.View(subServices);
            SqlCommand sqlCommand = new SqlCommand("tbl_lab_sub_service_Update", this.conn);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.Parameters.AddWithValue("@id", (object)subServices.lab_service_id);
            sqlCommand.Parameters.AddWithValue("@lab_services_description", (object)subServices.lab_services_description);
            sqlCommand.Parameters.AddWithValue("@lab_services_ext_description", (object)subServices.lab_services_ext_description);
            sqlCommand.Parameters.AddWithValue("@service_charges", (object)subServices.service_charges);
            sqlCommand.Parameters.AddWithValue("@client_billing_charges", (object)subServices.client_billing_charges);
            conn.Open();
            sqlCommand.ExecuteNonQuery();
            conn.Close();
            SqlCommand selectCommand = new SqlCommand("select lab_service_grp_id from tbl_lab_sub_service where id=@id", this.conn);
            selectCommand.Parameters.AddWithValue("@id", (object)subServices.lab_service_id);
            DataTable dataTable = new DataTable();
            new SqlDataAdapter(selectCommand).Fill(dataTable);
            if (dataTable.Rows.Count > 0)
                subServices.lab_group_id = Convert.ToInt32(dataTable.Rows[0]["lab_service_grp_id"]);
            return (ActionResult)this.RedirectToAction("UpdateServiceGroup", (object)new
            {
                id = subServices.lab_group_id
            });
        }

        public ActionResult DeleteSubService(int id)
        {
            SqlCommand sqlCommand = new SqlCommand("tbl_lab_sub_service_delete", this.conn);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.Parameters.AddWithValue("@id", (object)id);
            conn.Open();
            sqlCommand.ExecuteNonQuery();
            conn.Close();
            return (ActionResult)this.Redirect(Request.UrlReferrer.AbsolutePath);
        }

        public ActionResult ContactsList(string id)
        {
            ViewBag.locationid = id;
            List<Lab_contact> labContactList = new List<Lab_contact>();
            SqlCommand sqlCommand = new SqlCommand("select * from Tbl_Lab_location_Contact where lab_location_id=@id", this.conn);
            sqlCommand.Parameters.AddWithValue("@id", (object)id);
            conn.Open();
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            if (sqlDataReader.HasRows)
            {
                while (sqlDataReader.Read())
                    labContactList.Add(new Lab_contact()
                    {
                        firstname = sqlDataReader["firstname"].ToString(),
                        Lastname = sqlDataReader["Lastname"].ToString(),
                        officephone = sqlDataReader["officephone"].ToString(),
                        cell = sqlDataReader["cell"].ToString(),
                        email = sqlDataReader["email"].ToString(),
                        contact_id = Convert.ToInt32(sqlDataReader["lab_contact_id"].ToString())
                    });
                sqlDataReader.Close();
                conn.Close();
            }
            else
            {
                sqlDataReader.Close();
                conn.Close();
            }
            SqlCommand sqlCommand1 = new SqlCommand("select Location_Name from tbl_Clinic_Details where Location_id=@id", this.conn);
            sqlCommand1.Parameters.AddWithValue("@id", id.ToString());
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCommand1);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            ViewBag.LabName = dataTable.Rows[0]["Location_Name"].ToString();
            // ISSUE: reference to a compiler-generated field

            return (ActionResult)this.View((object)labContactList);
        }

        public ActionResult NewContact(string id)
        {
            return (ActionResult)this.View((object)new Lab_contact()
            {
                location_id = id
            });
        }

        [HttpPost]
        public ActionResult NewContact(Lab_contact _Contact)
        {
            if (!ModelState.IsValid)
                return (ActionResult)this.View((object)_Contact);
            SqlCommand sqlCommand = new SqlCommand("proc_insert_Lab_contact", this.conn);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.Parameters.AddWithValue("@lab_location_Id", (object)_Contact.location_id);
            sqlCommand.Parameters.AddWithValue("@firstname", (object)_Contact.firstname);
            sqlCommand.Parameters.AddWithValue("@lastname", (object)_Contact.Lastname);
            if (_Contact.officephone == null)
                sqlCommand.Parameters.AddWithValue("@officephone", (object)string.Empty);
            else
                sqlCommand.Parameters.AddWithValue("@officephone", (object)_Contact.officephone);
            if (_Contact.cell != null)
                sqlCommand.Parameters.AddWithValue("@cell", (object)_Contact.cell);
            else
                sqlCommand.Parameters.AddWithValue("@cell", string.Empty);
            sqlCommand.Parameters.AddWithValue("@email", (object)_Contact.email);
            conn.Open();
            sqlCommand.ExecuteNonQuery();
            conn.Close();
            return (ActionResult)this.RedirectToAction("ContactsList", (object)new
            {
                id = _Contact.location_id+"/"
            });
        }

        public ActionResult DeleteContact(int id)
        {
            SqlCommand sqlCommand = new SqlCommand("proc_delete_Lab_contact", this.conn);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.Parameters.AddWithValue("@lab_contact_id", (object)id);
            conn.Open();
            sqlCommand.ExecuteNonQuery();
            conn.Close();
            return (ActionResult)this.Redirect(Request.UrlReferrer.AbsolutePath);
        }


    }
}
